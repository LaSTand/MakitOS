/* for stdc */

#define GOLD_exit		exit
